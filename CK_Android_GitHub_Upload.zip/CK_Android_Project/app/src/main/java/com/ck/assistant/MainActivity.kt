package com.ck.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var input: EditText
    private lateinit var chat: LinearLayout
    private lateinit var prefs: SharedPreferences
    private lateinit var tts: TextToSpeech
    private var studyMode = false
    private val voiceRequest = 9001

    // Public HTTPS endpoint of the CK backend. No OpenAI key is stored in the app.
    private val backendUrl = "https://ck-ai.onrender.com/chat"
    private val history = mutableListOf<JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("ck_memory", MODE_PRIVATE)
        input = findViewById(R.id.input)
        chat = findViewById(R.id.chatContainer)
        tts = TextToSpeech(this, this)

        addMessage("CK", "Hi! I'm CK. AI backend connected. Ask me anything, or turn on Study Mode for Class 10 help.")

        findViewById<Button>(R.id.sendButton).setOnClickListener { send() }
        findViewById<ImageButton>(R.id.voiceButton).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.memoryButton).setOnClickListener { showMemory() }
        findViewById<Button>(R.id.studyButton).setOnClickListener {
            studyMode = !studyMode
            addMessage("CK", if (studyMode) "Study Mode ON — Class 10 Delhi Board focus enabled." else "Study Mode OFF.")
        }
        findViewById<Button>(R.id.webButton).setOnClickListener {
            val q = input.text.toString().trim()
            val url = if (q.isBlank()) "https://www.google.com/search?q=current+information"
                      else "https://www.google.com/search?q=" + Uri.encode(q)
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            addMessage("CK", "Opened web search. In V1, web results are not yet passed back into CK; secure verification backend comes in V1.1.")
        }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isBlank()) return
        addMessage("You", text)
        input.setText("")

        when {
            text.startsWith("/remember ", true) -> {
                val note = text.substringAfter(" ", "")
                prefs.edit().putString("note_${System.currentTimeMillis()}", note).apply()
                addMessage("CK", "Saved to CK's phone-only memory.")
            }
            text.equals("/memory", true) -> showMemory()
            text.equals("/clear-memory", true) -> {
                prefs.edit().clear().apply()
                addMessage("CK", "Phone-only memory cleared.")
            }
            else -> sendToBackend(text)
        }
    }

    private fun sendToBackend(text: String) {
        thread {
            try {
                val conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                    connectTimeout = 15000
                    readTimeout = 60000
                    doOutput = true
                }

                val body = JSONObject().apply {
                    put("message", text)
                    put("studyMode", studyMode)
                    put("history", JSONArray(history))
                }

                conn.outputStream.use {
                    it.write(body.toString().toByteArray(Charsets.UTF_8))
                }

                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()

                val json = if (responseText.isNotBlank()) JSONObject(responseText) else JSONObject()
                if (status !in 200..299) {
                    val error = json.optString("error", "Backend returned HTTP $status")
                    runOnUiThread { addMessage("CK", "Backend error: $error") }
                    return@thread
                }

                val answer = json.optString("answer", "No answer returned.")
                history.add(JSONObject().put("role", "user").put("content", text))
                history.add(JSONObject().put("role", "assistant").put("content", answer))

                runOnUiThread {
                    addMessage("CK", answer)
                    if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "ck-answer")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    addMessage("CK", "Backend connection failed. Check your internet connection and CK server.")
                }
            }
        }
    }

    private fun studyReply(q: String): String {
        return "Study Mode: Let's break this into an exam-friendly answer. Question: $q\n\n1) Definition / concept\n2) Key points\n3) Example\n4) Quick revision question\n\nAI-powered full answers will be connected after the secure backend is added."
    }

    private fun showMemory() {
        val all = prefs.all
        if (all.isEmpty()) {
            addMessage("CK", "Phone-only memory is empty.")
            return
        }
        val text = all.entries.joinToString("\n") { "• ${it.value}" }
        addMessage("CK", "Phone-only memory:\n$text")
    }

    private fun addMessage(who: String, text: String) {
        val tv = TextView(this)
        tv.text = if (who == "You") text else "$who  •  $text"
        tv.textSize = 16f
        tv.setTextColor(0xFF111111.toInt())
        tv.setPadding(16, 14, 16, 14)
        tv.gravity = if (who == "You") Gravity.END else Gravity.START
        chat.addView(tv)
    }

    private fun startVoice() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        startActivityForResult(intent, voiceRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!results.isNullOrEmpty()) input.setText(results[0])
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.ENGLISH
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
