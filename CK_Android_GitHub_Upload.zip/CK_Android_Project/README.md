# CK Android — Backend Connected

Backend endpoint used by this build:
`https://ck-ai.onrender.com/chat`

Security:
- No OpenAI API key is stored in the Android app.
- The OpenAI key stays in Render Environment Variables.
- The app uses HTTPS.

Build:
- Open this project in Android Studio or another Android build environment.
- Run `assembleDebug`.
- Install `app/build/outputs/apk/debug/app-debug.apk`.

The deployed `/health` endpoint has already been confirmed live. A real `/chat` POST should be tested from a networked client; this app now performs that POST when you press Send.
